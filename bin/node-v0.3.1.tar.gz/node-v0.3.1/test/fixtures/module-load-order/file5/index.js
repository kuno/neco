exports.file5 = 'file5/index.js';
